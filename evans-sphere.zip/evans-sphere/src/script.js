// Assuming you have a backend API to fetch movie data and handle authentication

function playMovie(movieId) {
    // Fetch movie details from the backend
    fetch(`/api/movies/${movieId}`)
        .then(response => response.json())
        .then(movieData => {
            // Set the video source
            const video = document.getElementById('video');
            video.src = movieData.videoUrl;
            video.load();
            video.play();
        });
}

// Example: Play a movie when a user clicks a button
document.getElementById('play-movie-button').addEventListener('click', () => {
    playMovie(123); // Replace 123 with the actual movie ID
});
const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const movieResults = document.getElementById('movie-results');

searchButton.addEventListener('click', () => {
    const searchTerm = searchInput.value;

    // Make API request using the search term
    fetch(`${API_ENDPOINT}?search=${searchTerm}`)
        .then(response => response.json())
        .then(data => {
            // Process the API response and display the movie results
            displayMovieResults(data);
        })
        .catch(error => {
            console.error('Error fetching movie data:', error);
        });
});

function displayMovieResults(movies) {
    movieResults.innerHTML = '';

    movies.forEach(movie => {
        const movieItem = document.createElement('div');
        movieItem.classList.add('movie-item');

        movieItem.innerHTML = `
            <h2>${movie.title}</h2>
            <img src="${movie.poster}" alt="${movie.title}">
            <p>${movie.plot}</p>
        `;

        movieResults.appendChild(movieItem);
    });
}
fetch('https://api.themoviedb.org/3/movie/popular?api_key=')
    .then(response => response.json())
    .then(data => {
        console.log(data.results); // Log the list of popular movies
    })
    .catch(error => {
        console.error('Error fetching movie data:', error);
    });const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const movieResults = document.getElementById('movie-results');

searchButton.addEventListener('click', () => {
    const searchTerm = searchInput.value;

    fetch(`https://api.themoviedb.org/3/search/movie?api_TMbd   API KEY&query=${searchTerm}`)
        .then(response => response.json())
        .then(data => {
            displayMovieResults(data.results);
        })
        .catch(error => {
            console.error('Error fetching movie data:', error);
        });
});

function displayMovieResults(movies) {
    movieResults.innerHTML = '';

    movies.forEach(movie => {
        const movieItem = document.createElement('div');
        movieItem.classList.add('movie-item');

        movieItem.innerHTML = `
            <h2>${movie.title}</h2>
            <img src="https://image.tmdb.org/t/p/w500/${movie.poster_path}" alt="${movie.title}">
            <p>${movie.overview}</p>
        `;

        movieResults.appendChild(movieItem);
    });
}
const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const movieResults = document.getElementById('movie-results');

searchButton.addEventListener('click', () => {
    const searchTerm = searchInput.value;

    fetch(`https://api.themoviedb.org/3/search/movie?api_key=TMdbApikey&query=${searchTerm}`)
        .then(response => response.json())
        .then(data => {
            displayMovieResults(data.results);
        })
        .catch(error => {
            console.error('Error fetching movie data:', error);
        });
});

function displayMovieResults(movies) {
    movieResults.innerHTML = '';

    movies.forEach(movie => {
        const movieItem = document.createElement('div');
        movieItem.classList.add('movie-item');

        movieItem.innerHTML = `
            <h2>${movie.title}</h2>
            <img src="https://image.tmdb.org/t/p/w500/${movie.poster_path}" alt="${movie.title}">
            <p>${movie.overview}</p>
        `;

        movieResults.appendChild(movieItem);
    });
}
function displayPopularMovies(movies) {
    const popularMoviesList = document.getElementById('popular-movies-list');

    movies.forEach(movie => {
        const movieItem = document.createElement('li');
        movieItem.innerHTML = `
            <img src="https://image.tmdb.org/t/p/w200/${movie.poster_path}" alt="${movie.title}">
            <p>${movie.title}</p>
        `;
        popularMoviesList.appendChild(movieItem);
    });
}https://image.tmdb.org/t/p/w200/${movie.poster_path}
const signupForm = document.getElementById('signup-form');

signupForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const name = signupForm.name.value;
    const email = signupForm.email.value;
    const password = signupForm.password.value;

    firebase.auth().createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            // User created successfully
            console.log('User created:', userCredential.user);

            // Redirect to a welcome page or display a success message
            window.location.href = '/welcome';
        })
        .catch((error) => {
            // Handle errors, display error message
            console.error('Error creating user:', error);
        });
});